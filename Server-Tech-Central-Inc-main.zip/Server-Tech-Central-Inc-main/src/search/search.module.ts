import { Module } from '@nestjs/common';
import { MeiliSearch } from 'meilisearch';

@Module({
  providers: [
    {
      provide: 'MEILISEARCH_CLIENT',
      useFactory: () => {
        return new MeiliSearch({
          host: 'http://localhost:7700',
          apiKey: 'masterKey123',
        });
      },
    },
  ],
  exports: ['MEILISEARCH_CLIENT'],
})
export class SearchModule {}
