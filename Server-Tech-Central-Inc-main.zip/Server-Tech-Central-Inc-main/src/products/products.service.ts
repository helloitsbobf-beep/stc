import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, ILike } from 'typeorm';
import { Product } from './entities/product.entity';
import { CreateProductDto } from './dto/create-product.dto';

@Injectable()
export class ProductsService {
  constructor(
    @InjectRepository(Product)
    private productRepository: Repository<Product>,
  ) {}

  async create(createProductDto: CreateProductDto): Promise<Product> {
    const product = this.productRepository.create(createProductDto);
    return this.productRepository.save(product);
  }

  async findAll(): Promise<Product[]> {
    return this.productRepository.find();
  }

  async findOne(id: string): Promise<Product> {
    const product = await this.productRepository.findOneBy({ id });
    if (!product) throw new NotFoundException(`Product ${id} not found`);
    return product;
  }

  /**
   * Fuzzy search implementation using Postgres ILIKE
   * Searches SKU and Name fields
   */
  async search(query: string): Promise<Product[]> {
    return this.productRepository.find({
      where: [
        { name: ILike(`%${query}%`) },
        { sku: ILike(`%${query}%`) },
        { description: ILike(`%${query}%`) }
      ],
      take: 20
    });
  }
}
