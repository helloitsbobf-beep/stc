import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity()
export class Product {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  sku: string;

  @Column()
  name: string;

  @Column({ type: 'text' })
  description: string;

  @Column({ name: 'base_price', type: 'decimal', precision: 10, scale: 2 })
  basePrice: number;

  @Column({ name: 'stock_level', type: 'int' })
  stockLevel: number;

  @Column({ type: 'jsonb', default: {} })
  attributes: Record<string, any>; // Stores technical specs e.g. { interface: "SAS", formFactor: "2.5" }

  @Column({ type: 'jsonb', name: 'tier_prices', nullable: true })
  tierPrices: Array<{ qty: number; price: number }>;

  @Column('text', { array: true, default: [] })
  compatibleIds: string[]; // SKUs of compatible parts
}
