import { Controller, Get, Post, Body, Param } from '@nestjs/common';
import { CmsService } from './cms.service';
import { ApiTags, ApiOperation } from '@nestjs/swagger';

@ApiTags('cms')
@Controller('cms')
export class CmsController {
  constructor(private readonly cmsService: CmsService) {}

  @Get()
  @ApiOperation({ summary: 'Get all content blocks' })
  getAll() {
    return this.cmsService.getAllContent();
  }

  @Get(':key')
  getOne(@Param('key') key: string) {
    return this.cmsService.getContent(key);
  }

  @Post(':key')
  @ApiOperation({ summary: 'Update a content block' })
  update(@Param('key') key: string, @Body() data: any) {
    return this.cmsService.updateContent(key, data);
  }
}