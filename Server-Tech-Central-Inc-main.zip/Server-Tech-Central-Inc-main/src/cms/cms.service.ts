import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ContentBlock } from './entities/content-block.entity';

@Injectable()
export class CmsService {
  constructor(
    @InjectRepository(ContentBlock)
    private contentRepository: Repository<ContentBlock>,
  ) {}

  async getContent(key: string): Promise<any> {
    const block = await this.contentRepository.findOneBy({ key });
    return block ? block.data : null;
  }

  async getAllContent(): Promise<Record<string, any>> {
    const blocks = await this.contentRepository.find();
    // Convert array of blocks to a single object: { key: data, key2: data2 }
    return blocks.reduce((acc, block) => {
      acc[block.key] = block.data;
      return acc;
    }, {});
  }

  async updateContent(key: string, data: any): Promise<ContentBlock> {
    const block = this.contentRepository.create({ key, data });
    return this.contentRepository.save(block);
  }
}