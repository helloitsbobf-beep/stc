
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Search, Upload, ShoppingCart, User } from 'lucide-react';

const Header = () => {
  const location = useLocation();
  const isHome = location.pathname === '/';

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
      <div className="container mx-auto px-4 h-20 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-4">
          <Link to="/" className="text-navy-900 tracking-tight focus:outline-none focus:ring-2 focus:ring-navy-500 rounded-sm">
            {isHome ? (
              <h1 className="text-2xl font-bold">SERVER TECH CENTRAL</h1>
            ) : (
              <span className="text-2xl font-bold">SERVER TECH CENTRAL</span>
            )}
          </Link>
        </div>

        {/* Super Search */}
        <div className="hidden md:flex flex-1 max-w-2xl mx-8 relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <label htmlFor="global-search" className="sr-only">Search catalog</label>
          <input
            id="global-search"
            type="text"
            className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-md leading-5 bg-gray-50 placeholder-gray-500 focus:outline-none focus:bg-white focus:ring-2 focus:ring-navy-800 focus:border-navy-800 sm:text-sm transition duration-150 ease-in-out"
            placeholder="Search by Part #, SKU, Model, or Keyword..."
            aria-label="Search products"
          />
        </div>

        {/* Actions */}
        <div className="flex items-center gap-6">
          <Link 
            to="/category" 
            className="hidden lg:flex items-center gap-2 text-sm font-medium text-navy-700 hover:text-navy-900 focus:outline-none focus:ring-2 focus:ring-navy-500 rounded-sm px-2 py-1"
          >
            <Upload className="w-4 h-4" />
            Upload BOM
          </Link>
          
          <div className="h-6 w-px bg-gray-300 hidden lg:block" aria-hidden="true"></div>

          <Link 
            to="/cart" 
            className="flex items-center gap-2 text-navy-900 hover:text-action-600 focus:outline-none focus:ring-2 focus:ring-navy-500 rounded-sm px-2 py-1"
            aria-label="View Shopping Cart, 2 items"
          >
            <div className="relative">
              <ShoppingCart className="w-6 h-6" />
              <span className="absolute -top-2 -right-2 bg-action-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                2
              </span>
            </div>
            <span className="hidden lg:inline text-sm font-semibold">Cart</span>
          </Link>
          
          <button 
            className="flex items-center gap-2 text-navy-700 hover:text-navy-900 focus:outline-none focus:ring-2 focus:ring-navy-500 rounded-full p-1"
            aria-label="User Account"
          >
            <User className="w-6 h-6" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
