
import React, { useEffect } from 'react';

const GoogleAnalytics = () => {
  // In a real environment, this would come from process.env.NEXT_PUBLIC_GA_ID
  const GA_MEASUREMENT_ID = 'G-XXXXXXXXXX'; 

  useEffect(() => {
    // Only load in production or if ID is present
    if (!GA_MEASUREMENT_ID) return;

    // Load GA Script
    const script = document.createElement('script');
    script.src = `https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`;
    script.async = true;
    document.head.appendChild(script);

    // Initialize
    const inlineScript = document.createElement('script');
    inlineScript.innerHTML = `
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', '${GA_MEASUREMENT_ID}', {
        page_path: window.location.pathname,
      });
    `;
    document.head.appendChild(inlineScript);

    return () => {
      // Cleanup if needed (rarely for GA)
      document.head.removeChild(script);
      document.head.removeChild(inlineScript);
    };
  }, []);

  return null;
};

export default GoogleAnalytics;
