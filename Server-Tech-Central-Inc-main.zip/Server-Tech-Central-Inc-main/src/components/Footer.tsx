import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck, Award } from 'lucide-react';
import { useGlobalContent } from '../contexts/GlobalContent';

const Footer = () => {
  const { content } = useGlobalContent();
  const { general, footer } = content;

  return (
    <footer className="bg-navy-900 text-white pt-12 border-t border-navy-800">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Column 1: Brand & identifiers */}
          <div>
            <h3 className="text-xl font-bold mb-4 tracking-tight">Server Tech Central</h3>
            <p className="text-gray-400 text-sm mb-6 leading-relaxed">
              {footer.aboutText}
            </p>
            
            <div className="bg-navy-800 rounded p-4 border border-navy-700">
              <h5 className="text-xs font-bold text-gray-300 uppercase mb-2 flex items-center gap-2">
                <ShieldCheck className="w-3 h-3 text-action-500" /> Government Identifiers
              </h5>
              <div className="flex justify-between text-xs text-gray-400 font-mono">
                <span>CAGE: <strong>8H7V2</strong></span>
                <span>DUNS: <strong>09-882-1234</strong></span>
              </div>
            </div>
          </div>

          {/* Column 2: Products */}
          <div>
            <h4 className="font-semibold mb-4 text-gray-200">Authorized Lines</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-action-500 rounded-full"></div> Cisco Enterprise</li>
              <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-action-500 rounded-full"></div> Seagate Storage</li>
              <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-action-500 rounded-full"></div> Fortinet Security</li>
              <li>Dell Technologies</li>
              <li>HPE</li>
            </ul>
          </div>

          {/* Column 3: Certifications */}
          <div>
            <h4 className="font-semibold mb-4 text-gray-200">Compliance</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li className="flex items-center gap-2">
                <Award className="w-4 h-4 text-yellow-500" /> ISO 9001 (Quality)
              </li>
              <li className="flex items-center gap-2">
                <Award className="w-4 h-4 text-yellow-500" /> ISO 14001 (Env)
              </li>
              <li className="flex items-center gap-2">
                <Award className="w-4 h-4 text-yellow-500" /> ISO 27001 (InfoSec)
              </li>
              <li>TAA Compliant</li>
            </ul>
          </div>

          {/* Column 4: Contact */}
          <div>
            <h4 className="font-semibold mb-4 text-gray-200">Contact</h4>
            <p className="text-sm text-gray-400 mb-1">{general.phone}</p>
            <p className="text-sm text-gray-400">{general.email}</p>
            <div className="mt-4 text-xs text-gray-500">
              <p>Headquarters:</p>
              <p>{general.address}</p>
            </div>
          </div>
        </div>

        {/* HTML Sitemap / Keyword Mesh */}
        <div className="border-t border-navy-800 pt-8 pb-8">
           <h5 className="text-xs font-bold text-gray-500 uppercase mb-4">Popular Hardware Searches</h5>
           <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 text-[11px] text-gray-400">
              <Link to="/category" className="hover:text-white transition">Refurbished Dell PowerEdge</Link>
              <Link to="/category" className="hover:text-white transition">HPE ProLiant Gen10</Link>
              <Link to="/category" className="hover:text-white transition">Cisco Catalyst 9200</Link>
              <Link to="/category" className="hover:text-white transition">Seagate Exos 16TB</Link>
              <Link to="/category" className="hover:text-white transition">Samsung Enterprise SSD</Link>
              <Link to="/category" className="hover:text-white transition">Ubiquiti Dream Machine</Link>
              <Link to="/category" className="hover:text-white transition">Used Server Parts</Link>
              <Link to="/category" className="hover:text-white transition">Bulk Hard Drives</Link>
              <Link to="/category" className="hover:text-white transition">10Gb SFP+ Transceivers</Link>
              <Link to="/category" className="hover:text-white transition">Server Rack Rails</Link>
              <Link to="/category" className="hover:text-white transition">Fortigate Firewalls</Link>
              <Link to="/category" className="hover:text-white transition">Synology NAS Drives</Link>
           </div>
        </div>

        <div className="border-t border-navy-800 py-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-500">
          <div>
            &copy; {new Date().getFullYear()} Server Tech Central. All rights reserved.
          </div>
          <div className="flex gap-4">
            <span>Privacy Policy</span>
            <span>Terms of Sale</span>
            <span>ISO Certificates</span>
            <Link to="/sitemap.xml">Sitemap</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;