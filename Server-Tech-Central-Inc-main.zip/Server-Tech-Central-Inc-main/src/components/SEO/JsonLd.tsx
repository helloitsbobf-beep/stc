
import React from 'react';
import { Product } from '../../types';

interface JsonLdProps {
  data: Product;
}

const JsonLd: React.FC<JsonLdProps> = ({ data }) => {
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "Product",
    "name": data.name,
    "image": [data.image],
    "description": data.description,
    "sku": data.sku,
    "mpn": data.sku,
    "brand": {
      "@type": "Brand",
      "name": data.brand
    },
    "offers": {
      "@type": "Offer",
      "url": window.location.href,
      "priceCurrency": "USD",
      "price": data.price,
      "itemCondition": "https://schema.org/NewCondition",
      "availability": data.stockStatus === 'IN_STOCK' 
        ? "https://schema.org/InStock" 
        : "https://schema.org/BackOrder"
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.8",
      "reviewCount": "24",
      "bestRating": "5",
      "worstRating": "1"
    },
    "review": [
      {
        "@type": "Review",
        "author": { "@type": "Person", "name": "IT Director, FinTech Corp" },
        "datePublished": "2023-10-15",
        "reviewBody": "Excellent condition and fast shipping. Deployed immediately into our production cluster.",
        "reviewRating": {
          "@type": "Rating",
          "ratingValue": "5",
          "bestRating": "5",
          "worstRating": "1"
        }
      }
    ]
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
    />
  );
};

export default JsonLd;
