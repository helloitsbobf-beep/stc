import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Order, OrderStatus, PaymentMethod } from './entities/order.entity';
import { CreateOrderDto } from './dto/create-order.dto';
import { Company } from '../companies/entities/company.entity';

@Injectable()
export class OrdersService {
  constructor(
    @InjectRepository(Order)
    private orderRepository: Repository<Order>,
    @InjectRepository(Company)
    private companyRepository: Repository<Company>,
  ) {}

  async create(createOrderDto: CreateOrderDto, companyId: string): Promise<Order> {
    const company = await this.companyRepository.findOneBy({ id: companyId });
    if (!company) throw new BadRequestException('Invalid Company ID');

    const order = this.orderRepository.create({
      ...createOrderDto,
      company,
    });

    // B2B Logic: Payment Method Validation
    if (createOrderDto.paymentMethod === PaymentMethod.PO) {
      if (!createOrderDto.poNumber) {
        throw new BadRequestException('PO Number is required for Purchase Order payments');
      }
      
      // Check credit limit (Simplified)
      if (company.creditLimit < createOrderDto.total) {
        throw new BadRequestException('Order exceeds company credit limit');
      }

      order.status = OrderStatus.PENDING_APPROVAL;
    } else {
      // Logic for Stripe would go here
      order.status = OrderStatus.PROCESSING;
    }

    return this.orderRepository.save(order);
  }

  async findAll(): Promise<Order[]> {
    return this.orderRepository.find({ relations: ['company'] });
  }
}
