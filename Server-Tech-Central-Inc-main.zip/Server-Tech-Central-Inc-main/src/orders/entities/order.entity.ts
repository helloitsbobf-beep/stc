import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn } from 'typeorm';
import { Company } from '../../companies/entities/company.entity';

export enum OrderStatus {
  PENDING_APPROVAL = 'PENDING_APPROVAL', // Waiting for PO check
  PROCESSING = 'PROCESSING',
  SHIPPED = 'SHIPPED',
  DELIVERED = 'DELIVERED',
  CANCELLED = 'CANCELLED'
}

export enum PaymentMethod {
  STRIPE = 'STRIPE',
  PO = 'PO' // Net 30 Terms
}

@Entity()
export class Order {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Company, (company) => company.orders)
  company: Company;

  @Column({ type: 'decimal', precision: 12, scale: 2 })
  total: number;

  @Column({ type: 'enum', enum: PaymentMethod })
  paymentMethod: PaymentMethod;

  @Column({ name: 'po_number', nullable: true })
  poNumber: string;

  @Column({ name: 'po_file_path', nullable: true })
  poFilePath: string;

  @Column({ type: 'enum', enum: OrderStatus, default: OrderStatus.PROCESSING })
  status: OrderStatus;

  @Column({ type: 'jsonb' })
  items: any; // Snapshot of items at time of purchase

  @CreateDateColumn()
  createdAt: Date;
}
