import { Product } from '../types';

export const mockProducts: Product[] = [
  {
    id: '1',
    name: 'Dell PowerEdge R740 Rack Server',
    sku: 'R740-XEON-GOLD',
    price: 3499.00,
    stockStatus: 'IN_STOCK',
    image: 'https://picsum.photos/id/0/500/500', // Placeholder tech image
    category: 'Servers',
    brand: 'Dell',
    description: 'The PowerEdge R740 was designed to accelerate application performance leveraging accelerator cards and storage scalability. The 2-socket, 2U platform has the optimum balance of resources to power the most demanding environments.',
    specs: {
      'Processor': '2x Intel Xeon Gold 6248R',
      'RAM': '64GB DDR4 ECC',
      'Storage': '2x 480GB SSD SATA',
      'Form Factor': '2U Rack',
      'Power Supply': 'Dual Hot-Plug 750W'
    }
  },
  {
    id: '2',
    name: 'Seagate Exos X16 14TB SAS HDD',
    sku: 'ST14000NM001G',
    price: 285.50,
    stockStatus: 'IN_STOCK',
    image: 'https://picsum.photos/id/1/500/500',
    category: 'Storage',
    brand: 'Seagate',
    description: 'Scalable, responsive, and innovative, the Exos X16 enterprise hard drive is designed for maximum storage capacity and the highest rack-space efficiency.',
    specs: {
      'Capacity': '14TB',
      'Interface': 'SAS 12Gb/s',
      'RPM': '7200',
      'Cache': '256MB',
      'Form Factor': '3.5 inch'
    }
  },
  {
    id: '3',
    name: 'Cisco Catalyst 9200L 48-Port Switch',
    sku: 'C9200L-48P-4G-E',
    price: 4250.00,
    stockStatus: 'BACKORDER',
    image: 'https://picsum.photos/id/2/500/500',
    category: 'Networking',
    brand: 'Cisco',
    description: 'Cisco Catalyst 9200 Series switches extend the power of intent-based networking and Catalyst 9000 hardware and software innovation to a broader set of deployments.',
    specs: {
      'Ports': '48 x 10/100/1000 (PoE+)',
      'Uplinks': '4 x 1G SFP',
      'PoE Budget': '740W',
      'Layer': 'Layer 3',
      'Stackable': 'Yes'
    }
  },
  {
    id: '4',
    name: 'HPE ProLiant DL380 Gen10',
    sku: 'P24841-B21',
    price: 2999.00,
    stockStatus: 'IN_STOCK',
    image: 'https://picsum.photos/id/3/500/500',
    category: 'Servers',
    brand: 'HPE',
    description: 'Adaptable for diverse workloads and environments, the secure 2P 2U HPE ProLiant DL380 Gen10 Server delivers world-class performance.',
    specs: {
      'Processor': 'Intel Xeon Silver 4208',
      'RAM': '32GB DDR4',
      'Storage Controller': 'P408i-a',
      'Form Factor': '2U Rack'
    }
  },
  {
    id: '5',
    name: 'Samsung PM1733 3.84TB NVMe SSD',
    sku: 'MZWLJ3T8HALS-00007',
    price: 550.00,
    stockStatus: 'IN_STOCK',
    image: 'https://picsum.photos/id/4/500/500',
    category: 'Storage',
    brand: 'Samsung',
    description: 'Samsung PM1733 PCIe Gen4 NVMe SSDs provide industry-leading performance for enterprise applications.',
    specs: {
      'Capacity': '3.84TB',
      'Interface': 'PCIe Gen4 x4',
      'Form Factor': 'U.2',
      'Read Speed': '7000 MB/s'
    }
  },
  {
    id: '6',
    name: 'Ubiquiti UniFi Dream Machine Pro',
    sku: 'UDM-Pro',
    price: 379.00,
    stockStatus: 'IN_STOCK',
    image: 'https://picsum.photos/id/5/500/500',
    category: 'Networking',
    brand: 'Ubiquiti',
    description: 'All-in-one enterprise security gateway and network appliance for small to medium-sized businesses.',
    specs: {
      'Processor': 'Quad-Core ARM Cortex-A57',
      'Memory': '4GB DDR4',
      'Flash': '16GB eMMC',
      'Rackmount': '1U'
    }
  }
];