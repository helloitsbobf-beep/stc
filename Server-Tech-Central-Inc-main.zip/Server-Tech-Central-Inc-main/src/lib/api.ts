
export const API_BASE = 'http://localhost:3000';

export async function fetchJson<T>(endpoint: string, options?: RequestInit): Promise<T | null> {
  try {
    const res = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers,
      },
    });
    
    if (!res.ok) {
        console.warn(`API Error ${res.status} for ${endpoint}`);
        return null;
    }
    
    return await res.json();
  } catch (err) {
    console.error(`Network error for ${endpoint}:`, err);
    return null;
  }
}
