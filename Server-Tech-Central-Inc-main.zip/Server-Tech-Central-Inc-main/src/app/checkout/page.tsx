
import React, { useState } from 'react';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import { CreditCard, FileText, Check, Truck, MapPin, ShieldCheck, BadgeCheck, Package, Plane, X, Loader2 } from 'lucide-react';
import { fetchJson, API_BASE } from '../../lib/api';

const CheckoutPage = () => {
  const [paymentMethod, setPaymentMethod] = useState<'CC' | 'PO'>('CC');
  const [addressTab, setAddressTab] = useState<'SHIPPING' | 'BILLING'>('SHIPPING');
  const [billingSameAsShipping, setBillingSameAsShipping] = useState(true);
  const [shippingMethod, setShippingMethod] = useState<'GROUND' | '2DAY' | 'OVERNIGHT'>('GROUND');
  const [poFile, setPoFile] = useState<File | null>(null);
  
  // Checkout State
  const [isProcessing, setIsProcessing] = useState(false);
  const [poNumber, setPoNumber] = useState('');

  const handlePoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.type === 'application/pdf') {
        setPoFile(file);
      } else {
        alert("Please select a valid PDF document.");
        e.target.value = ""; // Reset input
      }
    }
  };

  const handlePlaceOrder = async () => {
    setIsProcessing(true);

    const orderPayload = {
        total: 2450.00, // Example total, in real app comes from Cart Context
        paymentMethod: paymentMethod === 'CC' ? 'STRIPE' : 'PO',
        poNumber: paymentMethod === 'PO' ? poNumber : undefined,
        items: [] // In real app, cart items
    };

    try {
        const response = await fetch(`${API_BASE}/orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(orderPayload)
        });

        if (response.ok) {
            const data = await response.json();
            alert(`Order Placed Successfully! Order ID: ${data.id}`);
            // Redirect to success page would happen here
        } else {
            alert('Failed to place order. Please check your details.');
        }
    } catch (error) {
        console.error("Order error", error);
        alert('An unexpected error occurred. Please try again.');
    } finally {
        setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="container mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold text-navy-900 mb-8 text-center">Secure Checkout</h1>

        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* Left Column: Address Information (Tabbed) */}
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 min-h-[500px]">
              
              <h2 className="text-xl font-bold text-navy-900 mb-6 flex items-center gap-2">
                <span className="bg-navy-900 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs">1</span>
                Address Information
              </h2>

              {/* Address Tabs */}
              <div className="flex gap-4 mb-8">
                <button 
                  onClick={() => setAddressTab('SHIPPING')}
                  className={`flex-1 py-3 border rounded-lg flex items-center justify-center gap-2 font-medium transition focus:outline-none focus:ring-2 focus:ring-navy-500 ${addressTab === 'SHIPPING' ? 'bg-navy-50 border-navy-500 text-navy-900 ring-1 ring-navy-500 shadow-sm' : 'border-gray-200 text-gray-500 hover:bg-gray-50'}`}
                >
                  <Truck className="w-4 h-4" /> Shipping
                </button>
                <button 
                  onClick={() => setAddressTab('BILLING')}
                  className={`flex-1 py-3 border rounded-lg flex items-center justify-center gap-2 font-medium transition focus:outline-none focus:ring-2 focus:ring-navy-500 ${addressTab === 'BILLING' ? 'bg-navy-50 border-navy-500 text-navy-900 ring-1 ring-navy-500 shadow-sm' : 'border-gray-200 text-gray-500 hover:bg-gray-50'}`}
                >
                  <MapPin className="w-4 h-4" /> Billing
                </button>
              </div>

              {/* Shipping Content */}
              <div className={addressTab === 'SHIPPING' ? 'block animate-fadeIn' : 'hidden'}>
                <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-4">Shipping Address</h3>
                
                <form className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <input type="text" placeholder="First Name" className="w-full border border-gray-300 rounded p-2.5 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                    <input type="text" placeholder="Last Name" className="w-full border border-gray-300 rounded p-2.5 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                  </div>
                  <input type="text" placeholder="Company Name" className="w-full border border-gray-300 rounded p-2.5 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                  <input type="text" placeholder="Street Address" className="w-full border border-gray-300 rounded p-2.5 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                  <div className="grid grid-cols-3 gap-4">
                    <input type="text" placeholder="City" className="w-full border border-gray-300 rounded p-2.5 col-span-1 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                    <input type="text" placeholder="State" className="w-full border border-gray-300 rounded p-2.5 col-span-1 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                    <input type="text" placeholder="Zip" className="w-full border border-gray-300 rounded p-2.5 col-span-1 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                  </div>
                  <input type="tel" placeholder="Phone Number" className="w-full border border-gray-300 rounded p-2.5 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                </form>

                <div className="mt-8 pt-6 border-t border-gray-100 flex justify-end">
                   <button 
                     onClick={() => setAddressTab('BILLING')}
                     className="text-action-600 font-semibold text-sm hover:underline flex items-center gap-1"
                   >
                     Next: Billing Address &rarr;
                   </button>
                </div>
              </div>

              {/* Billing Content */}
              <div className={addressTab === 'BILLING' ? 'block animate-fadeIn' : 'hidden'}>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider">Billing Address</h3>
                  <label className="flex items-center gap-2 cursor-pointer select-none group">
                    <div className={`w-5 h-5 border rounded flex items-center justify-center transition-colors ${billingSameAsShipping ? 'bg-navy-900 border-navy-900' : 'bg-white border-gray-300 group-hover:border-navy-500'}`}>
                      {billingSameAsShipping && <Check className="w-3.5 h-3.5 text-white" />}
                    </div>
                    <input 
                      type="checkbox" 
                      className="hidden" 
                      checked={billingSameAsShipping}
                      onChange={(e) => setBillingSameAsShipping(e.target.checked)}
                    />
                    <span className="text-sm text-gray-700 font-medium">Same as shipping</span>
                  </label>
                </div>

                {!billingSameAsShipping ? (
                   <form className="space-y-4 bg-gray-50 p-4 rounded border border-gray-200">
                      <div className="grid grid-cols-2 gap-4">
                        <input type="text" placeholder="First Name" className="w-full border border-gray-300 rounded p-2.5 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                        <input type="text" placeholder="Last Name" className="w-full border border-gray-300 rounded p-2.5 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                      </div>
                      <input type="text" placeholder="Company Name" className="w-full border border-gray-300 rounded p-2.5 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                      <input type="text" placeholder="Street Address" className="w-full border border-gray-300 rounded p-2.5 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                      <div className="grid grid-cols-3 gap-4">
                        <input type="text" placeholder="City" className="w-full border border-gray-300 rounded p-2.5 col-span-1 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                        <input type="text" placeholder="State" className="w-full border border-gray-300 rounded p-2.5 col-span-1 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                        <input type="text" placeholder="Zip" className="w-full border border-gray-300 rounded p-2.5 col-span-1 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                      </div>
                   </form>
                ) : (
                  <div className="flex flex-col items-center justify-center h-48 text-gray-500 bg-gray-50 rounded border border-dashed border-gray-300">
                    <Check className="w-8 h-8 text-action-500 mb-2" />
                    <p className="text-sm font-medium">Billing address matches shipping</p>
                    <p className="text-xs mt-1">Uncheck the box above to edit</p>
                  </div>
                )}
              </div>

            </div>
          </div>

          {/* Right Column: Shipping & Payment */}
          <div className="space-y-6 h-fit sticky top-6">

            {/* Step 2: Shipping Method */}
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <h2 className="text-xl font-bold text-navy-900 mb-4 flex items-center gap-2">
                <span className="bg-navy-900 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs">2</span>
                Shipping Method
              </h2>
              <div className="space-y-3">
                {/* Ground */}
                <div 
                    onClick={() => setShippingMethod('GROUND')}
                    className={`flex items-center justify-between p-4 border rounded-lg cursor-pointer transition-all ${shippingMethod === 'GROUND' ? 'border-navy-600 bg-navy-50 ring-1 ring-navy-600' : 'border-gray-200 hover:border-gray-300'}`}
                >
                    <div className="flex items-center gap-3">
                        <Truck className={`w-5 h-5 ${shippingMethod === 'GROUND' ? 'text-navy-900' : 'text-gray-400'}`} />
                        <div>
                            <span className="block font-bold text-navy-900 text-sm">Free Ground</span>
                            <span className="block text-xs text-gray-500">5-7 Business Days</span>
                        </div>
                    </div>
                    <span className="font-bold text-navy-900 text-sm">Free</span>
                </div>

                {/* 2-Day */}
                <div 
                    onClick={() => setShippingMethod('2DAY')}
                    className={`flex items-center justify-between p-4 border rounded-lg cursor-pointer transition-all ${shippingMethod === '2DAY' ? 'border-navy-600 bg-navy-50 ring-1 ring-navy-600' : 'border-gray-200 hover:border-gray-300'}`}
                >
                    <div className="flex items-center gap-3">
                        <Package className={`w-5 h-5 ${shippingMethod === '2DAY' ? 'text-navy-900' : 'text-gray-400'}`} />
                        <div>
                            <span className="block font-bold text-navy-900 text-sm">2-Day Air</span>
                            <span className="block text-xs text-gray-500">Guaranteed Delivery</span>
                        </div>
                    </div>
                    <span className="font-bold text-navy-900 text-sm">$45.00</span>
                </div>

                {/* Overnight */}
                <div 
                    onClick={() => setShippingMethod('OVERNIGHT')}
                    className={`flex items-center justify-between p-4 border rounded-lg cursor-pointer transition-all ${shippingMethod === 'OVERNIGHT' ? 'border-navy-600 bg-navy-50 ring-1 ring-navy-600' : 'border-gray-200 hover:border-gray-300'}`}
                >
                    <div className="flex items-center gap-3">
                        <Plane className={`w-5 h-5 ${shippingMethod === 'OVERNIGHT' ? 'text-navy-900' : 'text-gray-400'}`} />
                        <div>
                            <span className="block font-bold text-navy-900 text-sm">Overnight</span>
                            <span className="block text-xs text-gray-500">Next Business Day</span>
                        </div>
                    </div>
                    <span className="font-bold text-navy-900 text-sm">$120.00</span>
                </div>
              </div>
            </div>
            
            {/* Step 3: Payment Method */}
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <h2 className="text-xl font-bold text-navy-900 mb-6 flex items-center gap-2">
                <span className="bg-navy-900 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs">3</span>
                Payment Method
              </h2>
              
              <div className="flex gap-4 mb-8">
                <button 
                  onClick={() => setPaymentMethod('CC')}
                  className={`flex-1 py-3 border rounded-lg flex items-center justify-center gap-2 font-medium transition focus:outline-none focus:ring-2 focus:ring-navy-500 ${paymentMethod === 'CC' ? 'bg-navy-50 border-navy-500 text-navy-900 ring-1 ring-navy-500 shadow-sm' : 'border-gray-200 text-gray-500 hover:bg-gray-50'}`}
                >
                  <CreditCard className="w-5 h-5" /> Credit Card
                </button>
                <button 
                  onClick={() => setPaymentMethod('PO')}
                  className={`flex-1 py-3 border rounded-lg flex items-center justify-center gap-2 font-medium transition focus:outline-none focus:ring-2 focus:ring-navy-500 ${paymentMethod === 'PO' ? 'bg-navy-50 border-navy-500 text-navy-900 ring-1 ring-navy-500 shadow-sm' : 'border-gray-200 text-gray-500 hover:bg-gray-50'}`}
                >
                  <FileText className="w-5 h-5" /> Purchase Order
                </button>
              </div>

              {paymentMethod === 'CC' ? (
                <div className="space-y-4 animate-fadeIn">
                  <input type="text" placeholder="Card Number" className="w-full border border-gray-300 rounded p-2.5 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                  <div className="grid grid-cols-2 gap-4">
                    <input type="text" placeholder="MM/YY" className="w-full border border-gray-300 rounded p-2.5 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                    <input type="text" placeholder="CVC" className="w-full border border-gray-300 rounded p-2.5 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" />
                  </div>
                </div>
              ) : (
                <div className="space-y-4 animate-fadeIn">
                  <div className="p-4 bg-blue-50 text-blue-800 text-sm rounded border border-blue-100">
                    <span className="font-bold">Net 30 Terms:</span> Subject to credit approval. Please upload your signed PO.
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">PO Number</label>
                    <input 
                      type="text" 
                      value={poNumber}
                      onChange={(e) => setPoNumber(e.target.value)}
                      className="w-full border border-gray-300 rounded p-2.5 text-sm focus:ring-2 focus:ring-navy-900 focus:outline-none" 
                      placeholder="PO-2023-XXXX" 
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Upload PO Document (PDF)</label>
                    {!poFile ? (
                      <input 
                        type="file" 
                        accept=".pdf" 
                        onChange={handlePoUpload}
                        className="w-full border border-gray-300 rounded p-2 text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-navy-50 file:text-navy-700 hover:file:bg-navy-100 cursor-pointer"
                      />
                    ) : (
                      <div className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded text-green-800 animate-fadeIn">
                        <div className="flex items-center gap-3">
                            <div className="bg-green-100 p-1.5 rounded-full">
                                <Check className="w-4 h-4 text-green-600" />
                            </div>
                            <div className="text-sm">
                                <span className="font-bold block text-green-700">File Uploaded Successfully</span>
                                <span className="text-xs text-green-600 block truncate max-w-[200px]">{poFile.name}</span>
                            </div>
                        </div>
                        <button 
                            onClick={() => setPoFile(null)} 
                            className="text-gray-400 hover:text-red-500 p-1 rounded-full hover:bg-red-50 transition"
                            title="Remove file"
                        >
                            <X className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <button 
                onClick={handlePlaceOrder}
                disabled={isProcessing}
                className="w-full mt-8 bg-action-600 hover:bg-action-500 disabled:bg-gray-400 text-white font-bold py-3.5 rounded shadow-lg transition transform active:scale-[0.99] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-action-600 flex items-center justify-center gap-2"
              >
                {isProcessing && <Loader2 className="w-5 h-5 animate-spin" />}
                {isProcessing ? 'Processing Order...' : 'Place Order'}
              </button>
              
              <div className="mt-4 flex items-center justify-center gap-2 text-xs text-gray-400">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                256-bit SSL Encrypted Transaction
              </div>
            </div>

            {/* Vendor Verification Card */}
            <div className="bg-white p-5 rounded-lg border border-gray-200 shadow-sm">
              <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-action-600" />
                Official Vendor Verification
              </h3>

              <div className="bg-navy-50 rounded border border-navy-100 p-3 mb-4">
                <div className="grid grid-cols-2 gap-2 text-xs font-mono text-navy-800">
                  <div>
                    <span className="block text-gray-500 text-[10px] uppercase font-sans mb-0.5">CAGE Code</span>
                    <span className="font-bold tracking-wide">8H7V2</span>
                  </div>
                  <div>
                    <span className="block text-gray-500 text-[10px] uppercase font-sans mb-0.5">DUNS Number</span>
                    <span className="font-bold tracking-wide">09-882-1234</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                 <div>
                    <div className="text-[10px] font-bold text-navy-900 mb-1.5 uppercase">ISO Certified</div>
                    <div className="flex flex-col gap-1 text-[10px] text-gray-600">
                        <div className="flex items-center gap-1"><BadgeCheck className="w-3 h-3 text-action-500" /> 9001 (Quality)</div>
                        <div className="flex items-center gap-1"><BadgeCheck className="w-3 h-3 text-action-500" /> 14001 (Env)</div>
                        <div className="flex items-center gap-1"><BadgeCheck className="w-3 h-3 text-action-500" /> 27001 (Sec)</div>
                    </div>
                 </div>
                 <div>
                    <div className="text-[10px] font-bold text-navy-900 mb-1.5 uppercase">Auth. Reseller</div>
                    <ul className="text-[10px] text-gray-600 space-y-1">
                       <li className="font-medium text-navy-700">Cisco Enterprise</li>
                       <li className="font-medium text-navy-700">Seagate Storage</li>
                       <li className="font-medium text-navy-700">Fortinet Security</li>
                    </ul>
                 </div>
              </div>
            </div>

          </div>

        </div>
      </div>
      <Footer />
    </div>
  );
};

export default CheckoutPage;
