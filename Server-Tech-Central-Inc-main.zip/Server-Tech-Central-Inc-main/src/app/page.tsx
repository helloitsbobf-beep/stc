
import React from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Hero from '../components/Hero';
import Footer from '../components/Footer';
import ProductCard from '../components/ProductCard';
import { useProductData } from '../hooks/useProductData';
import { Product } from '../types';
import { Shield, Truck, Server, Globe, CheckCircle, BarChart3, Building2, GraduationCap, Database, Award, BadgeCheck, HardDrive, Network, Cpu } from 'lucide-react';
import SEOHead from '../components/SEO/SEOHead';

const HomePage = () => {
  const { data: products, loading } = useProductData();
  const productList = products as Product[] || [];

  const orgSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "Server Tech Central",
    "url": "https://www.servertechcentral.com",
    "logo": "https://www.servertechcentral.com/logo.png",
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+1-800-555-0199",
      "contactType": "Sales",
      "areaServed": "US",
      "availableLanguage": "English"
    },
    "sameAs": [
      "https://www.linkedin.com/company/servertechcentral",
      "https://twitter.com/servertechcentral"
    ]
  };

  return (
    <div className="min-h-screen flex flex-col">
      <SEOHead 
        title="Enterprise Hardware Distributor | Servers, Storage & Networking | Server Tech Central"
        description="Leading B2B distributor of enterprise hardware. Buy refurbished and new Dell PowerEdge, HPE ProLiant, and Cisco networking gear. Same-day shipping available."
        canonicalUrl="https://www.servertechcentral.com"
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(orgSchema) }}
      />
      <Header />
      <Hero />
      
      {/* Trust Strip - ISO & Partners */}
      <div className="bg-white border-b border-gray-200 py-5">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-between items-center gap-6">
            
            {/* Certifications Left */}
            <div className="flex items-center gap-4 text-sm font-medium text-navy-800">
              <div className="flex items-center gap-1.5" title="Quality Management">
                <BadgeCheck className="w-5 h-5 text-action-600" /> 
                <span className="hidden md:inline">ISO</span> 9001
              </div>
              <div className="w-1 h-1 bg-gray-300 rounded-full"></div>
              <div className="flex items-center gap-1.5" title="Environmental Management">
                <BadgeCheck className="w-5 h-5 text-action-600" /> 
                <span className="hidden md:inline">ISO</span> 14001
              </div>
              <div className="w-1 h-1 bg-gray-300 rounded-full"></div>
              <div className="flex items-center gap-1.5" title="Information Security">
                <BadgeCheck className="w-5 h-5 text-action-600" /> 
                <span className="hidden md:inline">ISO</span> 27001
              </div>
            </div>

            <div className="h-6 w-px bg-gray-200 hidden lg:block"></div>

            {/* Official Partners Right */}
            <div className="flex items-center gap-6 text-gray-400 grayscale hover:grayscale-0 transition-all duration-500">
               <span className="text-xs uppercase font-bold text-gray-300 tracking-wider hidden md:block">Official Reseller:</span>
               <div className="flex items-center gap-6">
                 <span className="font-bold text-lg hover:text-[#00bceb]">CISCO</span>
                 <span className="font-bold text-lg hover:text-[#68be40]">Seagate</span>
                 <span className="font-bold text-lg hover:text-[#C02F2D]">Fortinet</span>
               </div>
            </div>
            
          </div>
        </div>
      </div>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-navy-900 mb-4">Why Procurement Teams Trust Us</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              We understand that downtime is not an option. Our infrastructure is built to support yours with speed, reliability, and financial flexibility.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-8 bg-gray-50 rounded-xl border border-gray-100 hover:shadow-lg transition duration-300">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-6 text-blue-700">
                <Globe className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-navy-900 mb-3">Global Logistics Network</h3>
              <p className="text-gray-600 leading-relaxed text-sm">
                With distribution centers in New York, California, and Texas, we offer same-day shipping on 95% of in-stock inventory. We provide blind drop-shipping and international pallet freight to data centers worldwide.
              </p>
            </div>

            <div className="p-8 bg-gray-50 rounded-xl border border-gray-100 hover:shadow-lg transition duration-300">
              <div className="w-12 h-12 bg-action-100 rounded-lg flex items-center justify-center mb-6 text-action-600">
                <CheckCircle className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-navy-900 mb-3">Rigorous QA Testing</h3>
              <p className="text-gray-600 leading-relaxed text-sm">
                Every server and drive that leaves our facility undergoes a 24-hour stress test. Our certified engineers verify firmware updates, clear logs, and ensure strict cosmetic standards for a "like-new" deployment experience.
              </p>
            </div>

            <div className="p-8 bg-gray-50 rounded-xl border border-gray-100 hover:shadow-lg transition duration-300">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-6 text-orange-600">
                <BarChart3 className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-navy-900 mb-3">Financial Services</h3>
              <p className="text-gray-600 leading-relaxed text-sm">
                We streamline procurement for enterprise clients. Access Net 30 terms, volume discounts, and detailed BOM (Bill of Materials) auditing. We accept University and Government Purchase Orders instantly.
              </p>
            </div>
          </div>
        </div>
      </section>

      <main className="bg-gray-50 py-16 border-t border-gray-200">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-end mb-8">
             <div>
                <h2 className="text-2xl font-bold text-navy-900">Featured Inventory</h2>
                <p className="text-gray-500 mt-1">High-demand components ready to ship.</p>
             </div>
             <Link to="/category" className="text-action-600 font-semibold hover:underline">View All &rarr;</Link>
          </div>

          {loading ? (
             <div className="text-center py-20 text-gray-500">Loading catalog...</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {productList.slice(0, 4).map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Explore by Category Section */}
      <section className="py-16 bg-white border-t border-gray-200">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-navy-900">Explore by Category</h2>
            <p className="text-gray-500 mt-2">Browse our specialized hardware divisions</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <Link to="/category" className="group p-6 border border-gray-200 rounded-xl hover:border-action-500 hover:shadow-md transition flex flex-col items-center text-center bg-gray-50 hover:bg-white">
              <div className="w-12 h-12 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center mb-4 group-hover:bg-action-100 group-hover:text-action-600 transition">
                <Server className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-navy-900 group-hover:text-action-600 transition">Servers</h3>
              <p className="text-xs text-gray-500 mt-2">Rack, Tower, & Blade Systems</p>
            </Link>

            <Link to="/category" className="group p-6 border border-gray-200 rounded-xl hover:border-action-500 hover:shadow-md transition flex flex-col items-center text-center bg-gray-50 hover:bg-white">
              <div className="w-12 h-12 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center mb-4 group-hover:bg-action-100 group-hover:text-action-600 transition">
                <HardDrive className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-navy-900 group-hover:text-action-600 transition">Storage</h3>
              <p className="text-xs text-gray-500 mt-2">HDD, SSD, & NVMe Arrays</p>
            </Link>

            <Link to="/category" className="group p-6 border border-gray-200 rounded-xl hover:border-action-500 hover:shadow-md transition flex flex-col items-center text-center bg-gray-50 hover:bg-white">
              <div className="w-12 h-12 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center mb-4 group-hover:bg-action-100 group-hover:text-action-600 transition">
                <Network className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-navy-900 group-hover:text-action-600 transition">Networking</h3>
              <p className="text-xs text-gray-500 mt-2">Switches, Routers, & Optics</p>
            </Link>

            <Link to="/category" className="group p-6 border border-gray-200 rounded-xl hover:border-action-500 hover:shadow-md transition flex flex-col items-center text-center bg-gray-50 hover:bg-white">
              <div className="w-12 h-12 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center mb-4 group-hover:bg-action-100 group-hover:text-action-600 transition">
                <Cpu className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-navy-900 group-hover:text-action-600 transition">Components</h3>
              <p className="text-xs text-gray-500 mt-2">Processors, RAM, & Parts</p>
            </Link>
          </div>
        </div>
      </section>

      {/* Industry Solutions Section */}
      <section className="py-20 bg-navy-900 text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="text-action-500 font-bold tracking-wider uppercase text-sm mb-2 block">Specialized Verticals</span>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 leading-tight">Tailored Hardware Solutions for Critical Industries</h2>
              <div className="space-y-6 text-gray-300 leading-relaxed">
                <p>
                  Server Tech Central isn't just a parts bin; we are a strategic partner for organizations where uptime is a matter of national security or educational continuity. Our supply chain expertise allows us to source legacy parts for aging infrastructure and the latest generation hardware for AI clusters.
                </p>
                <p>
                  We understand the unique billing and compliance requirements of the public sector. From strict TAA compliance for federal contracts to E-Rate funding cycles for school districts, our sales team is trained to navigate complex procurement landscapes.
                </p>
                <div className="flex gap-4 mt-6 items-center text-sm font-mono text-gray-400 bg-navy-950/50 p-4 rounded border border-navy-700 inline-block">
                  <span className="block">CAGE: <span className="text-white">8H7V2</span></span>
                  <span className="w-px h-4 bg-gray-600"></span>
                  <span className="block">DUNS: <span className="text-white">09-882-1234</span></span>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 gap-6">
              <div className="bg-navy-800 p-6 rounded-lg border border-navy-700 flex items-start gap-4">
                <Database className="w-8 h-8 text-blue-400 mt-1" />
                <div>
                  <h3 className="text-lg font-bold text-white mb-2">Hyperscale Data Centers</h3>
                  <p className="text-sm text-gray-400">High-density compute nodes, white-box servers, and bulk NVMe storage. Rapid provisioning for cloud expansion.</p>
                </div>
              </div>

              <div className="bg-navy-800 p-6 rounded-lg border border-navy-700 flex items-start gap-4">
                <Building2 className="w-8 h-8 text-action-500 mt-1" />
                <div>
                  <h3 className="text-lg font-bold text-white mb-2">Federal & Local Government</h3>
                  <p className="text-sm text-gray-400">TAA-Compliant hardware, secure chain of custody, and dedicated account managers for GSA contracts.</p>
                </div>
              </div>

              <div className="bg-navy-800 p-6 rounded-lg border border-navy-700 flex items-start gap-4">
                <GraduationCap className="w-8 h-8 text-orange-500 mt-1" />
                <div>
                  <h3 className="text-lg font-bold text-white mb-2">Education & Research</h3>
                  <p className="text-sm text-gray-400">HPC clusters for university research labs and reliable networking infrastructure for K-12 districts.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default HomePage;
