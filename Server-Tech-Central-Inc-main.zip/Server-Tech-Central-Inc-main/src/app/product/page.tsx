
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import Breadcrumbs from '../../components/Breadcrumbs';
import { useProductData } from '../../hooks/useProductData';
import { Product } from '../../types';
import { CheckCircle, Shield, FileText, ArrowRight, ShieldCheck, Award, Clock, Truck, Star, ThumbsUp, MessageSquare, BookOpen, ChevronDown, ChevronUp } from 'lucide-react';
import JsonLd from '../../components/SEO/JsonLd';
import Image from '../../components/Image';
import ProductLoading from './loading';
import ProductCard from '../../components/ProductCard';
import { mockProducts } from '../../lib/mockData';
import SEOHead from '../../components/SEO/SEOHead';

// In Next.js, this would be exported to generate server-side metadata
export async function generateMetadata({ params }: { params: { id: string } }) {
  // Placeholder for server-side logic
  return {
    title: `Product ${params.id} | Server Tech Central`
  };
}

const ShippingTimer = () => {
  const [timeLeft, setTimeLeft] = useState<{days: number, hours: number, minutes: number, label: string} | null>(null);

  useEffect(() => {
    const calculateTime = () => {
      const now = new Date();
      // Texas is Central Time (America/Chicago)
      // We parse the string to get the wall-clock time in Texas
      const txTimeStr = now.toLocaleString("en-US", { timeZone: "America/Chicago" });
      const txDate = new Date(txTimeStr);
      
      const currentDay = txDate.getDay(); // 0=Sun, 1=Mon, ..., 6=Sat
      
      let target = new Date(txDate);
      target.setHours(15, 0, 0, 0); // Target 3:00 PM
      
      let label = "Today";
      
      // Determine cutoff and shipping day logic
      if (currentDay === 6) { // Saturday
         target.setDate(target.getDate() + 2); // Move to Monday
         label = "Monday";
      } else if (currentDay === 0) { // Sunday
         target.setDate(target.getDate() + 1); // Move to Monday
         label = "Monday";
      } else {
         // Weekday (Mon-Fri)
         if (txDate > target) {
            // Missed today's cutoff
            target.setDate(target.getDate() + 1); // Tomorrow
            label = "Tomorrow";
            if (currentDay === 5) { // Friday afternoon -> Monday
               target.setDate(target.getDate() + 2); // Move to Monday
               label = "Monday";
            }
         }
      }
      
      const diff = target.getTime() - txDate.getTime();
      
      if (diff < 0) {
        // Fallback safety
        setTimeLeft(null); 
        return;
      }
      
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      
      setTimeLeft({ days, hours, minutes, label });
    };
    
    calculateTime();
    const interval = setInterval(calculateTime, 10000); // Update every 10 seconds for accuracy
    return () => clearInterval(interval);
  }, []);

  if (!timeLeft) return null;

  return (
    <div className="bg-blue-50 border border-blue-100 rounded-md p-3 mb-6 flex items-start gap-3">
      <Clock className="w-5 h-5 mt-0.5 text-blue-600 flex-shrink-0" />
      <div>
        <div className="text-sm font-bold text-navy-900 leading-tight">
           Order within {timeLeft.days > 0 ? `${timeLeft.days}d ` : ''}{timeLeft.hours} hr {timeLeft.minutes} min
        </div>
        <div className="text-xs text-blue-700 font-medium mt-1">
           for shipping <span className="font-bold underline decoration-blue-300 decoration-2 underline-offset-2">{timeLeft.label === 'Today' ? 'today' : `on ${timeLeft.label}`}</span> (Texas Time).
        </div>
      </div>
    </div>
  );
};

// --- SEO Helper Content ---
const getCategoryContent = (category: string, productName: string) => {
  if (category.includes('Server')) {
    return {
      title: "Enterprise Compute & Virtualization Performance",
      text: `The ${productName} is engineered to handle demanding workloads in modern data centers. Optimized for virtualization environments like VMware vSphere and Microsoft Hyper-V, this server platform delivers high-density computing power with redundant reliability. Whether deploying a hyper-converged infrastructure (HCI) or expanding a private cloud, this unit provides the scalability required for enterprise growth. Tested for thermal stability and power efficiency, it meets the rigorous standards of Tier 3 and Tier 4 data centers.`
    };
  } else if (category.includes('Storage')) {
     return {
      title: "Data Integrity & High-Throughput Archival",
      text: `Designed for 24/7 reliability, the ${productName} is an ideal solution for SAN, NAS, and DAS environments. With enterprise-class vibration tolerance and end-to-end data path protection, this storage device ensures data integrity for mission-critical applications. It is fully compatible with major RAID controllers and software-defined storage (SDS) stacks such as Ceph and vSAN. Perfect for big data analytics, backup repositories, and high-frequency transaction logging.`
    };
  } else if (category.includes('Networking')) {
     return {
      title: "Low-Latency Switching & Network Resilience",
      text: `Maximize your network backbone with the ${productName}. Built for high-bandwidth applications, this unit reduces latency in spine-leaf architectures and edge deployments. It supports advanced Layer 2 and Layer 3 protocols, ensuring seamless integration into existing Cisco, Juniper, or Arista environments. Featuring redundant power capabilities and hot-swappable fans, it is designed to maintain uptime during maintenance windows, making it a staple for ISPs and enterprise campus networks.`
    };
  }
  return {
    title: "Enterprise-Grade Reliability",
    text: `The ${productName} undergoes a comprehensive 28-point inspection process at our ISO 9001 certified facility. Designed for longevity and performance, this component is essential for maintaining business continuity in complex IT ecosystems.`
  };
};

const ProductPage = () => {
  const { id } = useParams<{ id: string }>();
  const { data, loading } = useProductData(id);
  const product = data as Product;
  const [activeTab, setActiveTab] = useState('specs');
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  // Logic for "Related Products" / Internal Linking Strategy
  const relatedProducts = mockProducts
    .filter(p => p.id !== id) // Exclude current product
    .slice(0, 4); // Limit to 4 for the grid

  if (loading) return <ProductLoading />;
  if (!product) return <div className="p-12 text-center text-navy-900 text-xl font-bold">Product not found.</div>;

  const techOverview = getCategoryContent(product.category, product.name);

  const productFaqs = [
    { q: "Does this product include rack rails?", a: "Rack rails are sold separately unless specified in the 'In the Box' section. We stock compatible sliding and static rails for this model." },
    { q: "Is the firmware updated before shipping?", a: "Yes. Our engineering team updates all firmware to the latest stable OEM release during our QA process to ensure immediate security compliance." },
    { q: "What is the return policy for this item?", a: "We offer a 30-day hassle-free return policy for unopened items. Defective units are covered under our 3-Year Advanced Replacement Warranty." }
  ];

  return (
    <div className="min-h-screen bg-white">
      <SEOHead 
        title={`${product.name} | ${product.sku} | Server Tech Central`}
        description={`Buy ${product.name} (${product.sku}). ${Object.values(product.specs).join(', ')}. Condition: New. ${product.stockStatus === 'IN_STOCK' ? 'In Stock' : 'Backordered'} at Server Tech Central.`}
        canonicalUrl={`https://www.servertechcentral.com/product/${product.id}`}
        type="product"
        image={product.image}
        price={product.price}
        availability={product.stockStatus === 'IN_STOCK' ? 'instock' : 'backorder'}
      />
      <JsonLd data={product} />
      <Header />
      
      {/* Dynamic Breadcrumbs */}
      <Breadcrumbs 
        items={[
          { label: product.category, path: '/category' },
          { label: product.sku, path: `/product/${product.id}` }
        ]} 
      />

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Col 1: Gallery (4 spans) */}
          <div className="lg:col-span-4">
            <div className="border border-gray-200 rounded-lg p-8 mb-4 bg-white flex items-center justify-center">
              <Image 
                src={product.image} 
                alt={`${product.name} - Front View`} 
                className="w-full h-auto object-contain max-h-[400px]" 
                width={500}
                height={500}
                priority={true}
              />
            </div>
            <div className="grid grid-cols-4 gap-2">
              {[1, 2, 3].map(i => (
                <button 
                  key={i} 
                  className="border border-gray-200 rounded cursor-pointer hover:border-navy-500 p-2 focus:outline-none focus:ring-2 focus:ring-navy-500"
                  aria-label={`View image ${i} of ${product.name}`}
                >
                  <Image 
                    src={product.image} 
                    alt={`${product.name} - Angle ${i}`} 
                    className="w-full h-full object-contain" 
                    width={100}
                    height={100}
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Col 2: Info & Specs (5 spans) */}
          <div className="lg:col-span-5">
            <h1 className="text-3xl font-bold text-navy-900 mb-2 leading-tight">{product.name}</h1>
            
            {/* Reviews Summary */}
            <div className="flex items-center gap-4 mb-4">
               <div className="flex items-center text-yellow-400">
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current text-gray-300" />
               </div>
               <a href="#reviews" className="text-sm text-action-600 hover:underline font-medium">4.8 (24 Reviews)</a>
            </div>

            <div className="flex items-center gap-4 mb-6">
              <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs font-mono">MPN: {product.sku}</span>
              {product.stockStatus === 'IN_STOCK' ? (
                <span className="text-action-600 text-sm font-medium flex items-center gap-1">
                  <CheckCircle className="w-4 h-4" /> In Stock
                </span>
              ) : (
                <span className="text-alert-500 text-sm font-medium flex items-center gap-1">
                  <Clock className="w-4 h-4" /> Backorder
                </span>
              )}
            </div>

            {/* Tabs */}
            <div className="border-b border-gray-200 mb-6" role="tablist">
              <div className="flex space-x-6">
                {['Description', 'Specs', 'Compatibility', 'Warranty'].map(tab => (
                  <button
                    key={tab}
                    role="tab"
                    aria-selected={activeTab === tab.toLowerCase()}
                    aria-controls={`${tab.toLowerCase()}-panel`}
                    onClick={() => setActiveTab(tab.toLowerCase())}
                    className={`py-2 text-sm font-medium border-b-2 transition focus:outline-none focus:text-navy-900 ${
                      activeTab === tab.toLowerCase() 
                      ? 'border-navy-900 text-navy-900' 
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>

            <article className="text-gray-600 text-sm leading-relaxed mb-8 min-h-[150px]" role="tabpanel" id={`${activeTab}-panel`}>
              {activeTab === 'description' && (
                <div itemProp="description" className="prose prose-sm max-w-none text-gray-600">
                  <p>{product.description}</p>
                  <p className="mt-4">
                    <strong>Deployment Ready:</strong> This unit is fully initialized and cleared of any previous configuration. 
                    It ships with our "Plug-and-Protect" guarantee, ensuring it mounts directly into standard 19-inch racks (rails may be sold separately).
                  </p>
                </div>
              )}
              {activeTab === 'specs' && (
                <table className="w-full text-left">
                  <tbody>
                    {Object.entries(product.specs).map(([key, value]) => (
                      <tr key={key} className="border-b border-gray-100">
                        <th scope="row" className="py-2 font-semibold text-gray-700 w-1/3">{key}</th>
                        <td className="py-2 text-gray-600">{value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </article>

            <div className="flex gap-4 text-xs text-gray-500 mt-8">
              <div className="flex items-center gap-1"><Shield className="w-4 h-4" /> 3-Year Warranty</div>
              <div className="flex items-center gap-1"><FileText className="w-4 h-4" /> Datasheet</div>
            </div>
          </div>

          {/* Col 3: Sticky Buy Box (3 spans) */}
          <div className="lg:col-span-3">
            {/* WRAPPER: Both cards are now sticky together */}
            <div className="sticky top-24 space-y-4">
              
              {/* Card 1: Main Buy Box */}
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 shadow-lg">
                <div className="mb-4">
                  <span className="text-gray-500 text-sm block">Your Price</span>
                  <span className="text-3xl font-bold text-navy-900">${product.price.toLocaleString()}</span>
                </div>
                
                {/* Shipping Ticker - Integrated into Buy Box */}
                <ShippingTimer />

                <div className="mb-6 space-y-3 text-sm">
                  <div className="flex justify-between text-gray-600">
                    <span>Availability:</span>
                    {product.stockStatus === 'IN_STOCK' ? (
                      <span className="font-semibold text-action-600">Immediate</span>
                    ) : (
                      <span className="font-semibold text-alert-500">Backordered</span>
                    )}
                  </div>
                  <div className="flex justify-between text-gray-600 items-center">
                    <span>Shipping:</span>
                    <span className="font-bold text-action-600 bg-action-100 px-2 py-0.5 rounded border border-action-200 flex items-center gap-1.5 shadow-sm">
                      <Truck className="w-3.5 h-3.5" /> Free Ground
                    </span>
                  </div>
                </div>

                <div className="space-y-3">
                  <button 
                    className="w-full bg-action-600 hover:bg-action-500 text-white font-bold py-3 px-4 rounded shadow-sm transition focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-action-600"
                    aria-label="Add to Cart"
                  >
                    Add to Cart
                  </button>
                  <button 
                    className="w-full bg-white border border-gray-300 hover:bg-gray-50 text-navy-900 font-semibold py-3 px-4 rounded transition focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-navy-500"
                    aria-label="Request Bulk Quote"
                  >
                    Request Bulk Quote
                  </button>
                </div>

                <div className="mt-6 pt-6 border-t border-gray-200 text-xs text-gray-500 text-center">
                  <p className="mb-2">Need it faster? Call us.</p>
                  <a href="tel:18005550199" className="font-bold text-navy-800 text-lg hover:underline" aria-label="Call support at 1-800-555-0199">1-800-555-0199</a>
                </div>
              </div>

              {/* Card 2: Compliance & Certification Badge (High Trust) */}
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <h4 className="text-xs font-bold text-navy-900 uppercase mb-3 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-action-600" /> Verified Distributor
                </h4>
                <ul className="space-y-2 text-xs text-gray-600">
                  <li className="flex items-start gap-2">
                    <Award className="w-3 h-3 text-navy-400 mt-0.5" />
                    <span>ISO 9001, 14001, 27001 Certified Facility</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Shield className="w-3 h-3 text-navy-400 mt-0.5" />
                    <span>Authorized Reseller: Cisco, Seagate, Fortinet</span>
                  </li>
                  <li className="flex items-start gap-2 border-t border-gray-100 pt-2 mt-2 font-mono text-gray-400">
                    <div className="flex flex-col">
                      <span>CAGE: 8H7V2</span>
                      <span>DUNS: 09-882-1234</span>
                    </div>
                  </li>
                </ul>
              </div>

            </div>
          </div>

        </div>

        {/* --- EXTENDED SEO CONTENT --- */}
        <section className="mt-16 border-t border-gray-200 pt-12">
           <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
              
              {/* Left Column: Technical Overview & Reviews */}
              <div className="lg:col-span-2 space-y-12">
                 
                 {/* Technical Deep Dive */}
                 <div>
                    <div className="flex items-center gap-2 mb-4">
                       <BookOpen className="w-5 h-5 text-action-600" />
                       <h2 className="text-xl font-bold text-navy-900">{techOverview.title}</h2>
                    </div>
                    <div className="prose prose-slate max-w-none text-gray-600 leading-relaxed bg-gray-50 p-6 rounded-lg border border-gray-100">
                       <p>{techOverview.text}</p>
                       <h3 className="text-sm font-bold text-navy-900 mt-4 uppercase tracking-wide">Key Features</h3>
                       <ul className="list-disc pl-5 space-y-1 mt-2">
                          <li>OEM Genuine Component verified by certified technicians.</li>
                          <li>Clean serial number ready for service contract registration.</li>
                          <li>Electrostatic Discharge (ESD) safe packaging.</li>
                          <li>Supports hot-swapping for zero-downtime maintenance.</li>
                       </ul>
                    </div>
                 </div>

                 {/* Reviews Section */}
                 <div id="reviews">
                    <div className="flex items-center justify-between mb-6">
                       <div className="flex items-center gap-2">
                          <MessageSquare className="w-5 h-5 text-action-600" />
                          <h2 className="text-xl font-bold text-navy-900">Verified Buyer Reviews</h2>
                       </div>
                       <button className="text-sm font-bold text-navy-900 border border-gray-300 px-4 py-2 rounded hover:bg-gray-50 transition">
                          Write a Review
                       </button>
                    </div>
                    
                    <div className="space-y-6">
                       <div className="border-b border-gray-100 pb-6">
                          <div className="flex items-center gap-2 mb-2">
                             <div className="flex text-yellow-400">
                                <Star className="w-3 h-3 fill-current" />
                                <Star className="w-3 h-3 fill-current" />
                                <Star className="w-3 h-3 fill-current" />
                                <Star className="w-3 h-3 fill-current" />
                                <Star className="w-3 h-3 fill-current" />
                             </div>
                             <span className="font-bold text-navy-900 text-sm">Perfect condition, fast shipping</span>
                          </div>
                          <p className="text-gray-600 text-sm mb-2">
                             "We needed this {product.category.slice(0, -1)} for an emergency replacement in our colocation rack. Arrived the next morning via overnight shipping. Packaging was excellent."
                          </p>
                          <div className="text-xs text-gray-400 flex items-center gap-2">
                             <span className="font-semibold text-gray-500">IT Director, FinTech Corp</span> • <span className="flex items-center gap-1"><CheckCircle className="w-3 h-3 text-action-500"/> Verified Purchase</span>
                          </div>
                       </div>

                       <div className="border-b border-gray-100 pb-6">
                          <div className="flex items-center gap-2 mb-2">
                             <div className="flex text-yellow-400">
                                <Star className="w-3 h-3 fill-current" />
                                <Star className="w-3 h-3 fill-current" />
                                <Star className="w-3 h-3 fill-current" />
                                <Star className="w-3 h-3 fill-current" />
                                <Star className="w-3 h-3 text-gray-200 fill-current" />
                             </div>
                             <span className="font-bold text-navy-900 text-sm">Solid enterprise hardware</span>
                          </div>
                          <p className="text-gray-600 text-sm mb-2">
                             "Matches the description perfectly. The firmware was slightly outdated but easily patched. Good price for the value."
                          </p>
                          <div className="text-xs text-gray-400 flex items-center gap-2">
                             <span className="font-semibold text-gray-500">System Admin, University Lab</span> • <span className="flex items-center gap-1"><CheckCircle className="w-3 h-3 text-action-500"/> Verified Purchase</span>
                          </div>
                       </div>
                    </div>
                 </div>

              </div>

              {/* Right Column: FAQ & Value Props */}
              <div className="lg:col-span-1 space-y-8">
                 
                 {/* Product FAQ */}
                 <div className="bg-white border border-gray-200 rounded-lg p-6">
                    <h3 className="font-bold text-navy-900 mb-4 text-lg">Product FAQ</h3>
                    <div className="space-y-4">
                       {productFaqs.map((faq, idx) => (
                          <div key={idx} className="border-b border-gray-100 last:border-0 pb-4 last:pb-0">
                             <button 
                                onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                                className="flex justify-between items-start w-full text-left group"
                             >
                                <span className="text-sm font-semibold text-navy-800 group-hover:text-action-600 transition">{faq.q}</span>
                                {openFaq === idx ? <ChevronUp className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" /> : <ChevronDown className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />}
                             </button>
                             {openFaq === idx && (
                                <p className="mt-2 text-xs text-gray-500 leading-relaxed animate-fadeIn">
                                   {faq.a}
                                </p>
                             )}
                          </div>
                       ))}
                    </div>
                 </div>

                 {/* Why Buy Here Box */}
                 <div className="bg-navy-900 text-white rounded-lg p-6">
                    <h3 className="font-bold text-lg mb-4">Why Server Tech Central?</h3>
                    <ul className="space-y-4 text-sm">
                       <li className="flex gap-3">
                          <div className="bg-navy-800 p-1.5 rounded h-fit"><ShieldCheck className="w-4 h-4 text-action-500" /></div>
                          <div>
                             <span className="font-bold block text-gray-200">Authenticity Guaranteed</span>
                             <span className="text-gray-400 text-xs">No gray market counterfeits. Only genuine OEM parts.</span>
                          </div>
                       </li>
                       <li className="flex gap-3">
                          <div className="bg-navy-800 p-1.5 rounded h-fit"><Truck className="w-4 h-4 text-action-500" /></div>
                          <div>
                             <span className="font-bold block text-gray-200">Blind Drop Shipping</span>
                             <span className="text-gray-400 text-xs">We ship directly to your client with your packing slip.</span>
                          </div>
                       </li>
                       <li className="flex gap-3">
                          <div className="bg-navy-800 p-1.5 rounded h-fit"><ThumbsUp className="w-4 h-4 text-action-500" /></div>
                          <div>
                             <span className="font-bold block text-gray-200">Expert Support</span>
                             <span className="text-gray-400 text-xs">Talk to engineers, not just sales reps.</span>
                          </div>
                       </li>
                    </ul>
                 </div>

              </div>
           </div>
        </section>

        {/* SEO Mesh: Internal Linking Strategy */}
        <section className="mt-20 border-t border-gray-200 pt-12">
           <div className="flex items-center justify-between mb-8">
             <h2 className="text-2xl font-bold text-navy-900">Frequently Bought Together</h2>
             <Link to="/category" className="text-action-600 font-semibold hover:underline flex items-center gap-1 text-sm">
               View All {product.category} <ArrowRight className="w-4 h-4" />
             </Link>
           </div>
           
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((related) => (
                  <ProductCard key={related.id} product={related} />
              ))}
           </div>
           
           {/* Semantic Deep Links for Crawlers */}
           <div className="mt-12 bg-gray-50 p-6 rounded-lg border border-gray-100 text-sm">
             <h3 className="font-semibold text-navy-900 mb-3">Explore Related Categories</h3>
             <div className="flex flex-wrap gap-3">
               {['Enterprise Servers', 'Rackmount Storage', 'Network Switches', 'SFP Transceivers', 'Server Memory (RAM)', 'Replacement Power Supplies'].map((tag, idx) => (
                 <Link key={idx} to="/category" className="px-3 py-1 bg-white border border-gray-200 rounded-full text-gray-600 hover:text-action-600 hover:border-action-500 transition">
                   {tag}
                 </Link>
               ))}
             </div>
           </div>
        </section>

      </main>
      <Footer />
    </div>
  );
};

export default ProductPage;
