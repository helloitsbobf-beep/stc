
import React from 'react';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import ProductCard from '../../components/ProductCard';
import Breadcrumbs from '../../components/Breadcrumbs';
import CategoryKnowledgeBase from '../../components/CategoryKnowledgeBase';
import { useProductData } from '../../hooks/useProductData';
import { Product } from '../../types';
import { ShieldCheck, Award } from 'lucide-react';
import SEOHead from '../../components/SEO/SEOHead';

const CategoryPage = () => {
  const { data: products, loading } = useProductData();
  const productList = products as Product[] || [];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <SEOHead 
        title="Enterprise Servers & Storage Solutions | Server Tech Central"
        description="Browse our catalog of over 500,000 enterprise servers, storage drives, and networking components. In-stock items ship same day. ISO 9001 Certified."
        canonicalUrl="https://www.servertechcentral.com/category"
      />
      <Header />
      <Breadcrumbs items={[{ label: 'Enterprise Hardware', path: '/category' }]} />
      
      {/* Top SEO Content Block */}
      <div className="bg-white border-b border-gray-200 py-10">
        <div className="container mx-auto px-4 max-w-6xl">
          <h1 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">
            Enterprise Servers & Storage Solutions
          </h1>
          <p className="text-gray-600 max-w-3xl text-lg leading-relaxed">
            Browse our extensive catalog of new and refurbished enterprise hardware. 
            We stock over 500,000 SKUs including <strong>Dell PowerEdge Servers</strong>, 
            <strong>HPE ProLiant</strong>, and <strong>Cisco Networking</strong> equipment. 
            All items are fully tested, include warranty, and are available for same-day shipping.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 flex-grow max-w-6xl">
        <div className="flex flex-col lg:flex-row gap-8">
          
          {/* Sidebar Filters */}
          <aside className="w-full lg:w-64 flex-shrink-0">
            {/* Trusted Distributor Badge (New) */}
            <div className="bg-navy-900 rounded-lg p-4 mb-6 text-white shadow-sm">
               <div className="flex items-center gap-2 mb-3">
                  <ShieldCheck className="w-5 h-5 text-action-500" />
                  <span className="font-bold text-sm">Verified Distributor</span>
               </div>
               <div className="space-y-2 text-xs text-gray-300">
                  <div className="flex items-center gap-2">
                    <Award className="w-3 h-3 text-action-500" />
                    <span>ISO 9001/14001/27001</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Award className="w-3 h-3 text-action-500" />
                    <span>Auth. Cisco & Seagate</span>
                  </div>
                  <div className="pt-2 border-t border-navy-700 font-mono text-[10px] text-gray-500">
                    CAGE: 8H7V2 | DUNS: 09-882-1234
                  </div>
               </div>
            </div>

            <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm sticky top-24">
              <h3 className="font-bold text-navy-900 mb-4">Filters</h3>
              
              <div className="space-y-6">
                <div>
                  <h4 className="text-sm font-semibold text-gray-900 mb-2">Brand</h4>
                  <div className="space-y-2">
                    {['Dell', 'HPE', 'Cisco', 'Seagate'].map(brand => (
                      <label key={brand} className="flex items-center group cursor-pointer">
                        <input type="checkbox" className="rounded border-gray-300 text-action-600 focus:ring-action-500 cursor-pointer" />
                        <span className="ml-2 text-sm text-gray-600 group-hover:text-navy-900">{brand}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-semibold text-gray-900 mb-2">Interface</h4>
                  <div className="space-y-2">
                    {['SAS 12Gb/s', 'SATA', 'NVMe', 'Fiber Channel'].map(item => (
                      <label key={item} className="flex items-center group cursor-pointer">
                        <input type="checkbox" className="rounded border-gray-300 text-action-600 focus:ring-action-500 cursor-pointer" />
                        <span className="ml-2 text-sm text-gray-600 group-hover:text-navy-900">{item}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-semibold text-gray-900 mb-2">Capacity</h4>
                  <div className="space-y-2">
                     {['1TB - 4TB', '5TB - 10TB', '12TB+', 'N/A'].map(item => (
                      <label key={item} className="flex items-center group cursor-pointer">
                        <input type="checkbox" className="rounded border-gray-300 text-action-600 focus:ring-action-500 cursor-pointer" />
                        <span className="ml-2 text-sm text-gray-600 group-hover:text-navy-900">{item}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              <button className="w-full mt-6 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 text-sm font-semibold rounded transition">
                Reset Filters
              </button>
            </div>
          </aside>

          {/* Product Grid */}
          <div className="flex-grow">
             <div className="flex justify-between items-center mb-6">
               <span className="text-sm text-gray-500 font-medium">Showing {productList.length} Results</span>
               <select className="border-gray-300 rounded text-sm py-1.5 pl-3 pr-8 focus:ring-navy-900 focus:border-navy-900 shadow-sm cursor-pointer">
                 <option>Sort by: Featured</option>
                 <option>Price: Low to High</option>
                 <option>Price: High to Low</option>
               </select>
             </div>

             {loading ? (
               <div className="flex justify-center items-center h-64">
                 <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-navy-900"></div>
               </div>
             ) : (
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                 {productList.map(product => (
                   <ProductCard key={product.id} product={product} />
                 ))}
               </div>
             )}
             
             {/* Pagination Placeholder */}
             <div className="mt-12 flex justify-center">
                <nav className="flex gap-2">
                   <button className="px-4 py-2 border border-gray-300 rounded text-sm font-medium hover:bg-gray-50">Previous</button>
                   <button className="px-4 py-2 bg-navy-900 text-white rounded text-sm font-medium">1</button>
                   <button className="px-4 py-2 border border-gray-300 rounded text-sm font-medium hover:bg-gray-50">2</button>
                   <button className="px-4 py-2 border border-gray-300 rounded text-sm font-medium hover:bg-gray-50">3</button>
                   <button className="px-4 py-2 border border-gray-300 rounded text-sm font-medium hover:bg-gray-50">Next</button>
                </nav>
             </div>
          </div>
        </div>
      </div>
      
      {/* Knowledge Base Section (The "SEO Sandwich" Bottom Layer) */}
      <CategoryKnowledgeBase />
      
      <Footer />
    </div>
  );
};

export default CategoryPage;
