import React from 'react';
import GoogleAnalytics from '../components/Analytics/GoogleAnalytics';
import { GlobalContentProvider } from '../contexts/GlobalContent';

const Layout = ({ children }: { children: React.ReactNode }) => {
  return (
    <GlobalContentProvider>
      <div className="flex flex-col min-h-screen font-sans text-navy-900 bg-slate-50">
        <GoogleAnalytics />
        {children}
      </div>
    </GlobalContentProvider>
  );
};

export default Layout;