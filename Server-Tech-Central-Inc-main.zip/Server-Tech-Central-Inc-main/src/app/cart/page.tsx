import React from 'react';
import { Link } from 'react-router-dom';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import { mockProducts } from '../../lib/mockData';
import { FileText, Trash2 } from 'lucide-react';

const CartPage = () => {
  // Simulating cart items from mock data
  const cartItems = [
    { ...mockProducts[0], quantity: 2 },
    { ...mockProducts[1], quantity: 5 }
  ];

  const subtotal = cartItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      <div className="container mx-auto px-4 py-10 flex-grow">
        <h1 className="text-3xl font-bold text-navy-900 mb-8">Shopping Cart</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Cart Table */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                    <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Qty</th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {cartItems.map((item) => (
                    <tr key={item.id}>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <img className="h-16 w-16 object-contain rounded border border-gray-200" src={item.image} alt={item.name} />
                          <div className="ml-4">
                            <div className="text-sm font-medium text-navy-900">{item.name}</div>
                            <div className="text-xs text-gray-500">MPN: {item.sku}</div>
                            <div className="text-xs text-gray-500 mt-1">Unit Price: ${item.price.toLocaleString()}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <input type="number" defaultValue={item.quantity} className="w-16 border-gray-300 rounded text-center text-sm" />
                      </td>
                      <td className="px-6 py-4 text-right text-sm font-semibold text-navy-900">
                        ${(item.price * item.quantity).toLocaleString()}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button className="text-red-500 hover:text-red-700">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-6">
              <button className="text-navy-700 font-medium hover:text-navy-900 flex items-center gap-2 text-sm">
                 <FileText className="w-4 h-4" /> Download Cart as Official PDF Quote
              </button>
            </div>
          </div>

          {/* Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-bold text-navy-900 mb-4">Order Summary</h2>
              <div className="space-y-3 text-sm border-b border-gray-200 pb-4 mb-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-semibold text-navy-900">${subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Shipping Estimate</span>
                  <span className="text-gray-500 italic">Calculated at checkout</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Tax</span>
                  <span className="text-gray-500 italic">--</span>
                </div>
              </div>
              <div className="flex justify-between text-lg font-bold text-navy-900 mb-6">
                <span>Total</span>
                <span>${subtotal.toLocaleString()}</span>
              </div>
              <Link 
                to="/checkout"
                className="block w-full text-center bg-action-600 hover:bg-action-500 text-white font-bold py-3 rounded shadow-sm transition"
              >
                Proceed to Checkout
              </Link>
              <div className="mt-4 text-center">
                 <span className="text-xs text-gray-500">Secure checkout via SSL</span>
              </div>
            </div>
          </div>

        </div>
      </div>
      <Footer />
    </div>
  );
};

export default CartPage;