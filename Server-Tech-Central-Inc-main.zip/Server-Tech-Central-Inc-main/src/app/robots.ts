
import { MetadataRoute } from 'next';

export default function robots() {
  return {
    rules: {
      userAgent: '*',
      allow: '/',
      disallow: ['/cart', '/checkout'],
    },
    sitemap: 'https://www.servertechcentral.com/sitemap.xml',
  };
}
