
import { mockProducts } from '../lib/mockData';

const baseUrl = 'https://www.servertechcentral.com';

export default async function sitemap() {
  const products = mockProducts.map((product) => ({
    url: `${baseUrl}/product/${product.id}`,
    lastModified: new Date(),
    changeFrequency: 'daily',
    priority: 0.8,
  }));

  const routes = [
    '',
    '/category',
    '/cart',
    '/checkout',
  ].map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: 'daily',
    priority: route === '' ? 1 : 0.5,
  }));

  return [...routes, ...products];
}
