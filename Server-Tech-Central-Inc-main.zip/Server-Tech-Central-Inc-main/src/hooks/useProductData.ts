
import { useState, useEffect } from 'react';
import { Product } from '../types';
import { mockProducts } from '../lib/mockData';
import { fetchJson } from '../lib/api';

/**
 * Abstraction Layer Hook
 * Switches between Real Backend API and Mock Data.
 */
export const useProductData = (productId?: string) => {
  const [data, setData] = useState<Product[] | Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<any>(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // Try fetching from real backend
        let result;
        if (productId) {
            result = await fetchJson<Product>(`/products/${productId}`);
        } else {
            result = await fetchJson<Product[]>('/products');
        }

        // If backend is running and returned data, use it.
        if (result) {
            setData(result);
        } else {
            // Fallback to Mock Data if backend is offline
            console.warn("Backend unavailable, using Mock Data");
            if (productId) {
                const found = mockProducts.find(p => p.id === productId);
                setData(found || null);
            } else {
                setData(mockProducts);
            }
        }
      } catch (err) {
        setError(err);
        // Fallback on error
        if (productId) {
            const found = mockProducts.find(p => p.id === productId);
            setData(found || null);
        } else {
            setData(mockProducts);
        }
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [productId]);

  return { data, loading, error };
};
