import { Module } from '@nestjs/common';
import { UsersModule } from '../users/users.module';
import { PassportModule } from '@nestjs/passport';
import { JwtModule } from '@nestjs/jwt';

@Module({
  imports: [
    UsersModule,
    PassportModule,
    JwtModule.register({
      secret: 'SECRETKEY', // Use env var in prod
      signOptions: { expiresIn: '60m' },
    }),
  ],
  providers: [], 
  controllers: [],
})
export class AuthModule {}
