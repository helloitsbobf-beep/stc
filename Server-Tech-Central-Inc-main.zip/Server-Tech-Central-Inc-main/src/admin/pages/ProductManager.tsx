
import React from 'react';
import { useProductData } from '../../hooks/useProductData';
import { Product } from '../../types';
import { Edit, Trash2, Plus, AlertCircle } from 'lucide-react';

const ProductManager = () => {
  const { data, loading } = useProductData();
  const products = (data as Product[]) || [];

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
           <h3 className="text-lg font-bold text-navy-900">Product Inventory</h3>
           <p className="text-sm text-gray-500">Manage catalog, pricing, and availability.</p>
        </div>
        <button className="bg-navy-900 hover:bg-navy-800 text-white px-4 py-2 rounded shadow flex items-center gap-2 text-sm font-bold">
           <Plus className="w-4 h-4" /> Add Product
        </button>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
         {loading ? (
             <div className="p-8 text-center text-gray-500">Loading inventory...</div>
         ) : products.length === 0 ? (
             <div className="p-8 text-center flex flex-col items-center text-gray-400">
                <AlertCircle className="w-8 h-8 mb-2" />
                No products found. Add one to get started.
             </div>
         ) : (
             <table className="w-full text-sm text-left">
               <thead className="bg-gray-50 border-b border-gray-200 text-gray-500 font-medium">
                 <tr>
                   <th className="px-6 py-3">Product</th>
                   <th className="px-6 py-3">SKU</th>
                   <th className="px-6 py-3">Category</th>
                   <th className="px-6 py-3">Price</th>
                   <th className="px-6 py-3">Stock</th>
                   <th className="px-6 py-3 text-right">Actions</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-gray-100">
                 {products.map((p) => (
                   <tr key={p.id} className="hover:bg-gray-50 transition">
                     <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                           {p.image && <img src={p.image} alt="" className="w-8 h-8 rounded border border-gray-200 object-contain" />}
                           <span className="font-medium text-navy-900 line-clamp-1">{p.name}</span>
                        </div>
                     </td>
                     <td className="px-6 py-4 font-mono text-xs">{p.sku}</td>
                     <td className="px-6 py-4 text-gray-500">{p.category}</td>
                     <td className="px-6 py-4 font-bold text-navy-900">${p.price.toLocaleString()}</td>
                     <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-bold ${p.stockStatus === 'IN_STOCK' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>
                           {p.stockStatus === 'IN_STOCK' ? 'In Stock' : 'Backorder'}
                        </span>
                     </td>
                     <td className="px-6 py-4 text-right">
                        <div className="flex justify-end gap-2">
                           <button className="p-1 text-gray-400 hover:text-navy-900"><Edit className="w-4 h-4" /></button>
                           <button className="p-1 text-gray-400 hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                        </div>
                     </td>
                   </tr>
                 ))}
               </tbody>
             </table>
         )}
      </div>
    </div>
  );
};

export default ProductManager;
