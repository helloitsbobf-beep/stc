
import React, { useState } from 'react';
import { useGlobalContent } from '../../contexts/GlobalContent';
import { Save, Loader2 } from 'lucide-react';

const ContentEditor = () => {
  const { content, updateContent } = useGlobalContent();
  
  // Local state for forms
  const [general, setGeneral] = useState(content.general);
  const [home, setHome] = useState(content.home);
  const [footer, setFooter] = useState(content.footer);
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    await Promise.all([
        updateContent('general', general),
        updateContent('home', home),
        updateContent('footer', footer)
    ]);
    setIsSaving(false);
    // In a real browser, we might show a toast notification here
    alert("Website updated successfully!");
  };

  return (
    <div className="max-w-4xl">
      <div className="flex justify-between items-center mb-6">
         <p className="text-gray-500">Edit global site text, contact info, and home page messaging.</p>
         <button 
           onClick={handleSave}
           disabled={isSaving}
           className="bg-action-600 hover:bg-action-500 disabled:bg-gray-400 text-white px-4 py-2 rounded shadow flex items-center gap-2 font-bold transition"
         >
           {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
           {isSaving ? 'Saving...' : 'Save Changes'}
         </button>
      </div>

      <div className="space-y-8">
        {/* General Settings Section */}
        <section className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-bold text-navy-900 mb-4 border-b pb-2">General Settings & Contact</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Company Phone</label>
              <input 
                type="text" 
                value={general.phone}
                onChange={(e) => setGeneral({...general, phone: e.target.value})}
                className="w-full border border-gray-300 rounded p-2 text-sm focus:ring-2 focus:ring-navy-900 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Support Email</label>
              <input 
                type="text" 
                value={general.email}
                onChange={(e) => setGeneral({...general, email: e.target.value})}
                className="w-full border border-gray-300 rounded p-2 text-sm focus:ring-2 focus:ring-navy-900 outline-none"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Physical Address</label>
              <input 
                type="text" 
                value={general.address}
                onChange={(e) => setGeneral({...general, address: e.target.value})}
                className="w-full border border-gray-300 rounded p-2 text-sm focus:ring-2 focus:ring-navy-900 outline-none"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Top Announcement Bar</label>
              <input 
                type="text" 
                value={general.announcement}
                onChange={(e) => setGeneral({...general, announcement: e.target.value})}
                className="w-full border border-gray-300 rounded p-2 text-sm bg-yellow-50 focus:ring-2 focus:ring-navy-900 outline-none"
              />
            </div>
          </div>
        </section>

        {/* Home Page Section */}
        <section className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-bold text-navy-900 mb-4 border-b pb-2">Home Page Hero</h3>
          <div className="space-y-4">
             <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Hero Headline</label>
              <input 
                type="text" 
                value={home.heroTitle}
                onChange={(e) => setHome({...home, heroTitle: e.target.value})}
                className="w-full border border-gray-300 rounded p-2 text-sm font-bold text-navy-900 focus:ring-2 focus:ring-navy-900 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Hero Subtitle</label>
              <textarea 
                value={home.heroSubtitle}
                onChange={(e) => setHome({...home, heroSubtitle: e.target.value})}
                rows={3}
                className="w-full border border-gray-300 rounded p-2 text-sm focus:ring-2 focus:ring-navy-900 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Call to Action Button Text</label>
              <input 
                type="text" 
                value={home.heroCta}
                onChange={(e) => setHome({...home, heroCta: e.target.value})}
                className="w-full border border-gray-300 rounded p-2 text-sm focus:ring-2 focus:ring-navy-900 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Hero Image URL</label>
              <input 
                type="text" 
                value={home.heroImage}
                onChange={(e) => setHome({...home, heroImage: e.target.value})}
                className="w-full border border-gray-300 rounded p-2 text-sm font-mono text-gray-500 focus:ring-2 focus:ring-navy-900 outline-none"
              />
            </div>
          </div>
        </section>

        {/* Footer Section */}
        <section className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-bold text-navy-900 mb-4 border-b pb-2">Footer Content</h3>
          <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">About Text (Column 1)</label>
              <textarea 
                value={footer.aboutText}
                onChange={(e) => setFooter({...footer, aboutText: e.target.value})}
                rows={3}
                className="w-full border border-gray-300 rounded p-2 text-sm focus:ring-2 focus:ring-navy-900 outline-none"
              />
            </div>
        </section>
      </div>
    </div>
  );
};

export default ContentEditor;
