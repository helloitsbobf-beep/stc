import React from 'react';
import { DollarSign, ShoppingCart, Users, Package } from 'lucide-react';

const StatCard = ({ title, value, change, icon: Icon, color }: any) => (
  <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
    <div className="flex justify-between items-start">
      <div>
        <p className="text-sm font-medium text-gray-500 mb-1">{title}</p>
        <h3 className="text-2xl font-bold text-navy-900">{value}</h3>
      </div>
      <div className={`p-3 rounded-lg ${color}`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
    </div>
    <div className="mt-4 flex items-center text-sm">
      <span className="text-green-600 font-medium">{change}</span>
      <span className="text-gray-400 ml-2">vs last month</span>
    </div>
  </div>
);

const Dashboard = () => {
  return (
    <div className="space-y-8">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Total Revenue" 
          value="$128,430" 
          change="+12.5%" 
          icon={DollarSign} 
          color="bg-action-600"
        />
        <StatCard 
          title="New Orders" 
          value="48" 
          change="+4.2%" 
          icon={ShoppingCart} 
          color="bg-blue-500"
        />
        <StatCard 
          title="Active Customers" 
          value="1,203" 
          change="+2.1%" 
          icon={Users} 
          color="bg-purple-500"
        />
        <StatCard 
          title="Low Stock SKUs" 
          value="12" 
          change="-5" 
          icon={Package} 
          color="bg-orange-500"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Orders Stub */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-bold text-navy-900 mb-4">Recent Orders</h3>
          <table className="w-full text-sm text-left">
            <thead>
              <tr className="border-b border-gray-100 text-gray-500">
                <th className="pb-3">Order ID</th>
                <th className="pb-3">Customer</th>
                <th className="pb-3">Total</th>
                <th className="pb-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {[1001, 1002, 1003, 1004].map(id => (
                <tr key={id} className="group hover:bg-gray-50">
                  <td className="py-3 font-mono text-navy-700">#{id}</td>
                  <td className="py-3">Acme Corp</td>
                  <td className="py-3 font-semibold">$2,450.00</td>
                  <td className="py-3"><span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">Processing</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* System Health */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-bold text-navy-900 mb-4">System Health</h3>
          <div className="space-y-4">
             <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Magento Sync</span>
                <span className="flex items-center gap-1 text-xs text-green-600 font-bold"><div className="w-2 h-2 bg-green-500 rounded-full"></div> Operational</span>
             </div>
             <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Meilisearch Index</span>
                <span className="flex items-center gap-1 text-xs text-green-600 font-bold"><div className="w-2 h-2 bg-green-500 rounded-full"></div> Operational</span>
             </div>
             <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">PostgreSQL DB</span>
                <span className="flex items-center gap-1 text-xs text-green-600 font-bold"><div className="w-2 h-2 bg-green-500 rounded-full"></div> Operational</span>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;