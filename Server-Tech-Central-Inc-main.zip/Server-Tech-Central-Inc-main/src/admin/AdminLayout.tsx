import React from 'react';
import { Link, useLocation, Outlet } from 'react-router-dom';
import { LayoutDashboard, ShoppingBag, FileText, Settings, LogOut, Package } from 'lucide-react';

const AdminLayout = () => {
  const location = useLocation();

  const navItems = [
    { label: 'Dashboard', path: '/admin', icon: LayoutDashboard },
    { label: 'Products', path: '/admin/products', icon: Package },
    { label: 'Orders', path: '/admin/orders', icon: ShoppingBag },
    { label: 'Content Editor', path: '/admin/content', icon: FileText },
    { label: 'Settings', path: '/admin/settings', icon: Settings },
  ];

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <aside className="w-64 bg-navy-900 text-white flex flex-col">
        <div className="p-6 border-b border-navy-800">
          <h1 className="text-xl font-bold tracking-tight">STC Admin</h1>
          <p className="text-xs text-gray-400 mt-1">Backend Portal</p>
        </div>
        
        <nav className="flex-grow p-4 space-y-2">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-md transition duration-200 text-sm font-medium ${
                  isActive 
                  ? 'bg-action-600 text-white shadow-md' 
                  : 'text-gray-300 hover:bg-navy-800 hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5" />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-navy-800">
          <button className="flex items-center gap-3 px-4 py-2 text-gray-400 hover:text-white transition w-full text-left text-sm">
            <LogOut className="w-5 h-5" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-grow overflow-auto">
        <header className="bg-white shadow-sm border-b border-gray-200 py-4 px-8 flex justify-between items-center sticky top-0 z-10">
          <h2 className="text-lg font-semibold text-navy-900">
            {navItems.find(i => i.path === location.pathname)?.label || 'Admin Area'}
          </h2>
          <div className="flex items-center gap-4">
            <div className="text-sm text-right">
              <p className="font-medium text-navy-900">Administrator</p>
              <p className="text-xs text-gray-500">super_admin@servertech.com</p>
            </div>
            <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center text-navy-700 font-bold">
              AD
            </div>
          </div>
        </header>
        <div className="p-8">
           <Outlet />
        </div>
      </main>
    </div>
  );
};

export default AdminLayout;