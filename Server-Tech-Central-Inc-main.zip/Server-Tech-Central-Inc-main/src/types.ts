export interface Product {
  id: string;
  name: string;
  sku: string; // MPN
  price: number;
  stockStatus: 'IN_STOCK' | 'BACKORDER' | 'OUT_OF_STOCK';
  image: string;
  category: string;
  brand: string;
  description: string;
  specs: Record<string, string>;
}

export interface CartItem extends Product {
  quantity: number;
}