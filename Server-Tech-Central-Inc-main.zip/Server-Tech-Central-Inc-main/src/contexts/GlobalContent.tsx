
import React, { createContext, useContext, useState, useEffect } from 'react';
import { fetchJson, API_BASE } from '../lib/api';

// Define the shape of our editable content
export interface ContentState {
  general: {
    phone: string;
    email: string;
    address: string;
    announcement: string;
  };
  home: {
    heroTitle: string;
    heroSubtitle: string;
    heroCta: string;
    heroImage: string;
  };
  footer: {
    aboutText: string;
  };
}

// Default/Fallback values (Used for SEO/Hydration before API loads)
const defaultContent: ContentState = {
  general: {
    phone: '1-800-555-0199',
    email: 'sales@servertechcentral.com',
    address: '100 Tech Plaza, Austin, TX 78701',
    announcement: 'Same Day Shipping on In-Stock Items',
  },
  home: {
    heroTitle: 'Enterprise Hardware.',
    heroSubtitle: 'Access over 500,000 SKUs of enterprise servers, storage, and networking gear. Real-time availability for mission-critical procurement.',
    heroCta: 'Shop All Inventory',
    heroImage: '/background123332.jpg',
  },
  footer: {
    aboutText: 'The premier B2B distributor for enterprise hardware, storage, and networking solutions.',
  },
};

interface GlobalContentContextType {
  content: ContentState;
  updateContent: (section: keyof ContentState, data: any) => Promise<void>;
  isLoading: boolean;
}

const GlobalContentContext = createContext<GlobalContentContextType>({
  content: defaultContent,
  updateContent: async () => {},
  isLoading: false,
});

export const GlobalContentProvider = ({ children }: { children: React.ReactNode }) => {
  const [content, setContent] = useState<ContentState>(defaultContent);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadContent = async () => {
      // Fetch all content blocks from the Backend CMS Module
      const data = await fetchJson<Record<string, any>>('/cms');
      
      if (data && Object.keys(data).length > 0) {
        // Merge backend data with default structure to ensure type safety
        setContent(prev => ({
          general: { ...prev.general, ...data.general },
          home: { ...prev.home, ...data.home },
          footer: { ...prev.footer, ...data.footer },
        }));
      }
      setIsLoading(false);
    };
    loadContent();
  }, []);

  const updateContent = async (section: keyof ContentState, data: any) => {
    // 1. Optimistic UI Update
    setContent(prev => ({
      ...prev,
      [section]: { ...prev[section], ...data }
    }));

    // 2. Persist to Backend
    try {
        await fetch(`${API_BASE}/cms/${section}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
    } catch (e) {
        console.error("Failed to save content", e);
        // Optionally revert state here on failure
    }
  };

  return (
    <GlobalContentContext.Provider value={{ content, updateContent, isLoading }}>
      {children}
    </GlobalContentContext.Provider>
  );
};

export const useGlobalContent = () => useContext(GlobalContentContext);
