import { Controller, Post, Body, Param, Patch, Get, Req } from '@nestjs/common';
import { QuotesService } from './quotes.service';
import { ApiTags, ApiOperation } from '@nestjs/swagger';

@ApiTags('quotes')
@Controller('quotes')
export class QuotesController {
  constructor(private readonly quotesService: QuotesService) {}

  @Post()
  @ApiOperation({ summary: 'Request a new bulk quote' })
  requestQuote(@Body() body: any) {
    // In real app, extract User from Req
    // return this.quotesService.requestQuote(req.user, body.items);
    return { message: "Quote requested" }; 
  }

  @Patch(':id/approve')
  @ApiOperation({ summary: 'Admin approves quote with custom price' })
  approveQuote(@Param('id') id: string, @Body('total') total: number) {
    return this.quotesService.approveQuote(id, total);
  }
}
