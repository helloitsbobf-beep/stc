import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn } from 'typeorm';
import { User } from '../../users/entities/user.entity';

export enum QuoteStatus {
  PENDING = 'PENDING',
  REVIEWED = 'REVIEWED',
  ACCEPTED = 'ACCEPTED',
  REJECTED = 'REJECTED'
}

@Entity()
export class Quote {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => User, (user) => user.quotes)
  user: User;

  @Column({ type: 'jsonb' })
  items: Array<{ productId: string; qty: number; requestedPrice?: number }>;

  @Column({ type: 'enum', enum: QuoteStatus, default: QuoteStatus.PENDING })
  status: QuoteStatus;

  @Column({ name: 'negotiated_total', type: 'decimal', precision: 12, scale: 2, nullable: true })
  negotiatedTotal: number;

  @CreateDateColumn()
  createdAt: Date;
}
