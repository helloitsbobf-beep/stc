import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Quote, QuoteStatus } from './entities/quote.entity';
import { User } from '../users/entities/user.entity';

@Injectable()
export class QuotesService {
  constructor(
    @InjectRepository(Quote)
    private quoteRepository: Repository<Quote>,
  ) {}

  async requestQuote(user: User, items: any[]): Promise<Quote> {
    const quote = this.quoteRepository.create({
      user,
      items,
      status: QuoteStatus.PENDING,
    });
    return this.quoteRepository.save(quote);
  }

  async findAll(): Promise<Quote[]> {
    return this.quoteRepository.find({ relations: ['user', 'user.company'] });
  }

  async findOne(id: string): Promise<Quote> {
    return this.quoteRepository.findOne({ where: { id }, relations: ['user'] });
  }

  /**
   * B2B Logic: Admin approves a quote and sets a custom negotiated price.
   */
  async approveQuote(id: string, negotiatedTotal: number): Promise<Quote> {
    const quote = await this.findOne(id);
    if (!quote) throw new NotFoundException('Quote not found');

    quote.status = QuoteStatus.REVIEWED;
    quote.negotiatedTotal = negotiatedTotal;
    
    // In a real app, trigger Email Notification Service here
    console.log(`Email sent to ${quote.user.email}: Quote Ready for review.`);

    return this.quoteRepository.save(quote);
  }

  async acceptQuote(id: string): Promise<Quote> {
    const quote = await this.findOne(id);
    quote.status = QuoteStatus.ACCEPTED;
    return this.quoteRepository.save(quote);
  }
}
